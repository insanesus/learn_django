"""
Custom filters to be used in templates

There are some things that can only be done in python and not in template, so we make functions to do such tasks in python, register them as a filter using 'register' decorator
"""

from django import template

# create an instance of django.template.Library, which is used to register custom tempalate tags and filters
register = template.Library()


@register.filter
def is_list(value):
    return isinstance(value, list)


@register.filter
def is_tuple(value):
    return isinstance(value, tuple)
