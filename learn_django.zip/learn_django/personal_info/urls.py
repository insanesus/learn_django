from django.urls import path

from .import views

urlpatterns = [
    path('', views.index, name='index'),
    path('contact_info/', views.info, name="contact_info"),
    path('datatype/<int:passval>/', views.datatypefun, name="datatype"),
]