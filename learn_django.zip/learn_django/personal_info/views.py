from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader


def index(request):
    context = {
        'title': 'Learn Django',
        'phone': ['9841220033', '9841222222']
    }
    
    return render(request, 'info_list.html', context)


def info(request):
    contact_info = {
        'address': 'Kathmandu',
        'phone': ['9841220033', '9841222222'],
        'email': ('contactme@gmail.com', 'myemailid@outlook.com')
    }
    context = {
        'contact_details': contact_info
    }

    template = loader.get_template('contact_info.html')
    return HttpResponse(template.render(context, request))


def datatypefun(request, passval):
    return HttpResponse(passval)